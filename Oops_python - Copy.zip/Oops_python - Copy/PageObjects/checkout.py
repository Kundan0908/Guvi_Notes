from time import sleep

from selenium.webdriver.common.by import By


class Checkout:
    def __init__(self,driver):
        self.driver = driver
        self.click_cart_button = (By.XPATH,"//*[text()='Cart']")
        self.select_order = (By.XPATH,"//button[text()='Place Order']")
        self.order_name = (By.ID,"name")
        self.order_country = (By.ID,'country')
        self.order_city = (By.ID,"city")
        self.order_card = (By.ID,'card')
        self.order_month = (By.ID,"month")
        self.order_year = (By.ID,'year')
        self.purchase_order = (By.XPATH,"//button[text()='Purchase']")
        self.verify_click = (By.XPATH,"//*[text()='OK']")
        self.verify_order_details = (By.XPATH,"//*[@class='lead text-muted ']")

    def place_order(self):
        self.driver.find_element(*self.click_cart_button).click()
        sleep(2)
        self.driver.find_element(*self.select_order).click()

    def checkout_details(self,order_name,order_country,order_city,order_card,order_month,order_year):
        self.driver.find_element(*self.order_name).send_keys(order_name)
        self.driver.find_element(*self.order_country).send_keys(order_country)
        self.driver.find_element(*self.order_city).send_keys(order_city)
        self.driver.find_element(*self.order_card).send_keys(order_card)
        self.driver.find_element(*self.order_month).send_keys(order_month)
        self.driver.find_element(*self.order_year).send_keys(order_year)

    def confirm_order(self):
        self.driver.find_element(*self.purchase_order).click()
        sleep(4)

    def verify_order(self):
        # order_details = self.driver.find_elements(*self.verify_order_details)
        # for details in order_details:
        #     print(details.text)
        print(self.driver.find_element(*self.verify_order_details).text)
        self.driver.find_element(*self.verify_click).click()
