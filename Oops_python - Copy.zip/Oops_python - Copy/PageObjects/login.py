from time import sleep

from selenium.webdriver.common.by import By


class Testlogin:
    def __init__(self,driver):
        self.click_login = (By.ID,"login2")
        self.username_id = (By.ID,"loginusername")
        self.password = (By.ID, "loginpassword")
        self.submit = (By.XPATH,"(//button[@class='btn btn-primary'])[3]")
        self.driver = driver

    def login_(self,username,password):
        self.driver.find_element(*self.click_login).click()
        self.driver.find_element(*self.username_id).send_keys(username)
        self.driver.find_element(*self.password).send_keys(password)
        self.driver.find_element(*self.submit).click()
