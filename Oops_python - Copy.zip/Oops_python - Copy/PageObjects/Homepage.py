from time import sleep

from selenium.webdriver.common.by import By


class Homepage():
    def __init__(self,driver):
        self.object_tile = (By.XPATH,"//*[@class='col-lg-4 col-md-6 mb-4']")
        self.add_to_cart = (By.XPATH,"//*[@class='btn btn-success btn-lg']")
        self.driver = driver

    def add_product_to_cart(self,user_input):
        products = self.driver.find_elements(*self.object_tile)
        for product in products:
            if product.find_element(By.XPATH,'div/div/h4/a').text == user_input:
                product.find_element(By.XPATH,'div/div/h4/a').click()
                break
        sleep(4)
        self.driver.find_element(*self.add_to_cart).click()
        sleep(2)
        alert = self.driver.switch_to.alert
        alert.accept()