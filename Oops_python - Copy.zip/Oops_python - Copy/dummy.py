lst1 = [10,1,11,100,98,56,32]
lst1.sort()
diff = 0
for i in range(len(lst1)):
    for j in range(i+1)
    diff