import pytest

def testdemo2():
    print('hello')